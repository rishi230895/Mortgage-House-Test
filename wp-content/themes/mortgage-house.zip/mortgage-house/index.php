<?php
    // Silence is golden.